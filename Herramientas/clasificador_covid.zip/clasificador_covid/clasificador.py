from qgis.core import *
from qgis import *
import processing

class Clasificador:

    def __init__(self, layers, nombre_campo, path):
        self.layers = layers
        self.nombre_campo = nombre_campo
        self.path = path

        for layer in self.layers:
            self.calcula_porcentaje(layer, self.nombre_campo, self.path)

    def calcula_porcentaje(self, layer, nombre_campo, path):
        statistics_data = {
            "INPUT_LAYER": layer,
            "FIELD_NAME": "covid",
        }

        stats = processing.run('qgis:basicstatisticsforfields', statistics_data)
        total = stats['SUM']

        new_field = "porc_cov"

        field_calc_data = {
            "INPUT": layer,
            "FIELD_NAME": new_field,
            "FIELD_TYPE": 0,
            "FIELD_LENGTH":10,
            "FIELD_PRECISION": 4,
            "NEW_FIELD": True,
            "FORMULA": "(" + nombre_campo + " * 100)/" + str(total),
            "OUTPUT": path + layer.name() + "_v2.shp"
        }

        result = processing.run('qgis:fieldcalculator', field_calc_data)
        new_layer = QgsVectorLayer(result['OUTPUT'], layer.name()+"_v2", "ogr")
        QgsProject.instance().addMapLayer(new_layer)

        self.mapa_tematico(new_layer, new_field)

    def mapa_tematico(self, layer, new_field):
        symbol = QgsFillSymbol()
        clasificacion = [QgsGraduatedSymbolRenderer.Quantile]
        style = QgsStyle().defaultStyle()
        color_ramp = style.colorRampNames()
        ramp = style.colorRamp(color_ramp[34])
        field = new_field
        renderer = QgsGraduatedSymbolRenderer.createRenderer(layer, field, 5, clasificacion[0], symbol, ramp)
        layer.setRenderer(renderer)
        ruta = layer.source().split(".shp")
        layer.saveNamedStyle(ruta[0] + ".qml")
